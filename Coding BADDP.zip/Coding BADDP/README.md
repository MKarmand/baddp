# belajar-analisis-data--dengan-python

#Install Requirements

```
pip install -r requirements.txt

```

#Run Dashboard

```
streamlit run baddp.py